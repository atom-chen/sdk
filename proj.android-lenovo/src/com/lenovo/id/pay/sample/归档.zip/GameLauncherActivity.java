package com.lenovo.id.pay.sample;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;



import com.lenovo.id.pay.sample.data.Config;
import com.lenovo.lsf.gamesdk.IAuthResult;
import com.lenovo.lsf.gamesdk.LenovoGameApi;
import com.lenovo.lsf.gamesdk.LenovoGameApi;
import com.lenovo.lsf.lenovoid.utility.RealAuthConstants;
import com.lenovo.pop.utility.Constants;
import com.pay.sample.lenovo.R;

//import com.unity3d.player.UnityPlayer;
//import com.unity3d.player.UnityPlayerActivity;
//import com.unity3d.player.UnityPlayerNativeActivity;

public class GameLauncherActivity extends Activity {
	private static final int MSG_LOGIN_AUTO_ONEKEY = 2;
	private AlertDialog.Builder alertDialogBuilder;
	//private UnityPlayer mUnityPlayer;

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
	//	getWindow().takeSurface(null);
      //  getWindow().setFormat(PixelFormat.RGBX_8888); // <--- This makes xperia play happy
      //  mUnityPlayer = new UnityPlayer(this);
      // setContentView(mUnityPlayer);
      //  mUnityPlayer.requestFocus();

		
		initViews();
	}

	/**
	 * UI初始化
	 */
	private void initViews() {
		
		/**
		 * 加载游戏资源:在此处建议您将加载游戏资源的代码模块放到这里，这样做的好处是因为下面getTokenByQuickLogin()这个方法是个异步方法，可以做到
		 * 边加载资源一边进行后台快速登录
		 */
		setContentView(R.layout.load_resource);

		//SDK初始化
		LenovoGameApi.doInit(GameLauncherActivity.this,Config.appid);
		
		// 调用快速登录接口
		/**
	       * 什么是快速登录：
	       * 如果用户已经在系统中登录，则本接口会通过SSO机制直接返回登录结果;
	       * 如果用户尚未在系统中登录，则本接口会通过后台短信方式进行自动登录尝试，通常需要10~20s左右时间;
		   * 由于自动登录需要发短信，因此请使用装有SIM卡的手机进行开发测试;
	       * 登录期间，会弹出一个提示框，提示用户正在尝试自动登录;
	       * 如果自动登录失败，会提示用户重试，以及引导用户使用其他方式登录。
	       */
		getTokenByQuickLogin();

		// 退出游戏
		alertDialogBuilder = new AlertDialog.Builder(this)
				.setMessage("是否确定退出？").setCancelable(true)
				.setPositiveButton("是", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						GameLauncherActivity.this.finish();
					}
				})
				.setNegativeButton("否", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
	}

	
	
	
	private void showView(final String lpsust) {

		// 进入商城按钮
		final Button buyBtn = (Button) findViewById(R.id.pay_into);
		buyBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// 发起进入商城
				Intent intent = new Intent(GameLauncherActivity.this,GoodsListActivity.class);
				intent.putExtra("lpsust", lpsust);
				startActivity(intent);
				finish();
			}
		});
		final Button check = (Button) findViewById(R.id.check_realauth);
		check.setVisibility(View.GONE);

		check.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//注意！替换成自己的openappid
				LenovoGameApi.doCheckRealAuth(GameLauncherActivity.this, lpsust, "1410232134070.app.ln",new IAuthResult() {
					@Override
					public void onFinished(boolean ret, String data) {
						if(ret){//已经实名注册
							String[] a =  data.split("-");
							Log.i("demo", "doCheckRealAuth a:["+a[0]+","+a[1]+"]");

							if(RealAuthConstants.REAL_AUTH_OVER_EIGHTEEN.equals(a[1])){
								Toast.makeText(GameLauncherActivity.this, "已实名认证，已成年,出生日期："+a[0], Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_UNDER_EIGHTEEN.equals(a[1])){
								Toast.makeText(GameLauncherActivity.this, "已实名认证，未成年,出生日期："+a[0], Toast.LENGTH_SHORT).show();
							}
						}else{
							if(TextUtils.isEmpty(data)){
								Toast.makeText(GameLauncherActivity.this, "查询失败", Toast.LENGTH_SHORT).show();
							}else{
								Toast.makeText(GameLauncherActivity.this, "未实名认证", Toast.LENGTH_SHORT).show();
							}
						}
						
					}
				});

			}
		});
		final Button registun = (Button) findViewById(R.id.regist_realauth_unforce);
		registun.setVisibility(View.GONE);
		registun.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//注意！替换成自己的openappid
				LenovoGameApi.doRegistRealAuth(GameLauncherActivity.this, lpsust,"1410232134070.app.ln", false/*是否强制注册*/, new IAuthResult() {
					
					@Override
					public void onFinished(boolean ret, String data) {
						if(ret){//实名注册成功
							String[] a =  data.split("-");
							Log.i("demo", "doRegistRealAuth a:["+a[0]+","+a[1]+","+a[2]+"]");

							if(RealAuthConstants.REAL_AUTH_SUCCESS_SURE.equals(a[0])){
								//有效验证
							}else if(RealAuthConstants.REAL_AUTH_SUCCESS_NOT_SURE.equals(a[0])){
								//快速验证 如果这种结果建议隔段时间再次查询doCheckRealAuth
							}
							if(RealAuthConstants.REAL_AUTH_OVER_EIGHTEEN.equals(a[2])){
								Toast.makeText(GameLauncherActivity.this, "实名认证成功，已成年,出生日期："+a[1], Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_UNDER_EIGHTEEN.equals(a[2])){
								Toast.makeText(GameLauncherActivity.this, "实名认证成功，未成年,出生日期："+a[1], Toast.LENGTH_SHORT).show();
							}
						}else{//实名注册失败
							String[] a =  data.split("-");
							Log.i("demo", "doRegistRealAuth a:["+a[0]+","+a[1]+","+a[2]+"]");

							if(RealAuthConstants.REAL_AUTH_FAIL_CANCLE.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:用户取消", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_LACK_PARAMS.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:缺少参数", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_INVALID_ST.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:无效的ST", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_NET_ERROR_TO_ID.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:通讯异常", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_EMPTY_NAME.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:身份证姓名为空", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_ERROR_NAME.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:身份证姓名错误", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_ERROR_ID.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:身份证号码错误", Toast.LENGTH_SHORT).show();
							}if(RealAuthConstants.REAL_AUTH_FAIL.equals(a[0])){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:认证失败", Toast.LENGTH_SHORT).show();
							}
						}
						
						
					}
				});
			}
		});
		final Button regist = (Button) findViewById(R.id.regist_realauth_force);
		regist.setVisibility(View.GONE);
		regist.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//注意！替换成自己的openappid
				LenovoGameApi.doRegistRealAuth(GameLauncherActivity.this, lpsust, "1410232134070.app.ln",true/*是否强制注册*/, new IAuthResult() {
					
					@Override
					public void onFinished(boolean ret, String data) {
						if(ret){//实名注册成功
							String[] a =  data.split("-");
							Log.i("demo", "doRegistRealAuth a:["+a[0]+","+a[1]+","+a[2]+"]");
							if(RealAuthConstants.REAL_AUTH_SUCCESS_SURE.equals(a[0])){
								//有效验证
							}else if(RealAuthConstants.REAL_AUTH_SUCCESS_NOT_SURE.equals(a[0])){
								//快速验证 如果这种结果建议隔段时间再次查询doCheckRealAuth
							}
							if(RealAuthConstants.REAL_AUTH_OVER_EIGHTEEN.equals(a[1])){
								Toast.makeText(GameLauncherActivity.this, "实名认证成功，已成年,出生日期："+a[2], Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_UNDER_EIGHTEEN.equals(a[1])){
								Toast.makeText(GameLauncherActivity.this, "实名认证成功，未成年,出生日期："+a[2], Toast.LENGTH_SHORT).show();
							}
						}else{
							//当为强制注册时，用户不能取消，只能成功
							/*if(RealAuthConstants.REAL_AUTH_FAIL_CANCLE.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:用户取消", Toast.LENGTH_SHORT).show();
							}*/
							if(RealAuthConstants.REAL_AUTH_FAIL_LACK_PARAMS.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:缺少参数", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_INVALID_ST.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:无效的ST", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_NET_ERROR_TO_ID.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:通讯异常", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_EMPTY_NAME.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:身份证姓名为空", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_ERROR_NAME.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:身份证姓名错误", Toast.LENGTH_SHORT).show();
							}else if(RealAuthConstants.REAL_AUTH_FAIL_ERROR_ID.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:身份证号码错误", Toast.LENGTH_SHORT).show();
							}if(RealAuthConstants.REAL_AUTH_FAIL.equals(data)){
								Toast.makeText(GameLauncherActivity.this, "实名认证失败:认证失败", Toast.LENGTH_SHORT).show();
							}
						}
						
						
					}
				});
			}
		});
		
	}
	 // Resume Unity
    /*@Override
    protected void onResume() {
        super.onResume();
        mUnityPlayer.resume();

    }

    // Pause Unity
    @Override
    protected void onPause() {
        super.onPause();

        mUnityPlayer.pause();
    }*/
	/**
	 * 后台快捷登录
	 */
	private void getTokenByQuickLogin() {

		//请不要在回调函数里进行UI操作，如需进行UI操作请使用handler将UI操作抛到主线程
		LenovoGameApi.doAutoLogin(this, new IAuthResult() {

			@Override
			public void onFinished(boolean ret, String data) {
				final Message msg = new Message();
				msg.what = MSG_LOGIN_AUTO_ONEKEY;
				msg.obj = data;
				if (ret) {
					myHandler.sendMessage(msg);

				} else {
					//后台快速登录失败(失败原因开启飞行模式、 网络不通等)
					Log.i(Config.TAG, "login fail");
				}
			}
		});

	}
	/*@Override
    protected void onDestroy() {
        mUnityPlayer.quit();
        super.onDestroy();
    }
	 // Notify Unity of the focus change.
    @SuppressLint("NewApi")
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        mUnityPlayer.windowFocusChanged(hasFocus);
        if (hasFocus) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                // 隐藏底部导航栏,SYSTEM_UI_FLAG_IMMERSIVE_STICKY可以让导航栏出现后自动隐藏
                int flag = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
                getWindow().getDecorView().setSystemUiVisibility(flag);
            }
        }
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mUnityPlayer.configurationChanged(newConfig);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_MULTIPLE)
            return mUnityPlayer.injectEvent(event);
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }
    public boolean onGenericMotionEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }*/
	/**
	 * 功能： 该方法的作用是Handler对传递过来的不同消息，进行不同的处理。 当传递过来的消息是MSG_LOGIN时，则对登录进行相应的处理；
	 */
	private Handler myHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MSG_LOGIN_AUTO_ONEKEY:
				// 登录成功

				setContentView(R.layout.game_main);
				showView((String)msg.obj);
				break;
			default:
				break;
			}
		};
	};

	/**
	 * 返回键
	 */
	@Override
	public void onBackPressed() {
		//alertDialogBuilder.show();
		LenovoGameApi.doQuit(GameLauncherActivity.this,  new IAuthResult() {
			@Override
			public void onFinished(boolean result, String data) {
				Log.i("demo", "onFinished："+data);
				if(result){
					GameLauncherActivity.this.finish();
					System.exit(0);
				}else{
					//"用户点击底部返回键或点击弹窗close键"
				}
				/*if(result == 0){//"用户点击弹窗close键"
					GameLauncherActivity.this.finish();
					System.exit(0);
				}else if(result == -1){//"用户点击底部返回键"
				}else if(result == -2){//"用户点击弹窗open键"
					GameLauncherActivity.this.finish();
					System.exit(0);
				}*/
			}

		});
	}
}
