package com.lenovo.id.pay.sample;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpResponse;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.lenovo.id.pay.sample.data.Config;
import com.lenovo.id.pay.sample.net.HttpJsonParser;
import com.lenovo.id.pay.sample.net.HttpUtil;
import com.lenovo.id.pay.sample.net.HttpUtilException;
import com.lenovo.id.pay.sample.net.HttpUtil.RequestMethod;
import com.lenovo.lsf.gamesdk.IAuthResult;
import com.lenovo.lsf.gamesdk.LenovoGameApi;
import com.lenovo.lsf.gamesdk.GamePayRequest;
import com.lenovo.lsf.gamesdk.IPayResult;
import com.lenovo.pay.api.PayManagerActivity;
import com.lenovo.pop.utility.Constants;
import com.pay.sample.lenovo.R;

public class GoodsListActivity extends Activity {

	private Button payButton;
	private AlertDialog.Builder alertDialogBuilder;
	private static final String CONTENTTYPE = "application/x-www-form-urlencoded";
	private static final int MSG_CHECK_PAY_SUCCESS = 10;
	private static final int MSG_GET_ORDER_ID_SUCCESS = 11;
	private static final int MAX_REQUEST_COUNT = 50;
	private String mlpsustdata;
	
	private static String hostUrl = /*"http://vbtest.lenovomm.cn/orderService/";*/"http://cashier.lenovomm.com:8085/";//"http://uss.test.lenovomm.cn/";//游戏服务器url
	private static final int MSG_CHECK_PAY_FAIL = 12;// 从游戏服务器验证订单支付失败

	/**
	 * 功能： 该方法的作用是Handler对传递过来的不同消息，进行不同的处理。
	 */
	private Handler myHandlerEx = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MSG_CHECK_PAY_SUCCESS://从游戏服务器验证订单支付成功
				Toast.makeText(GoodsListActivity.this, "sample:支付成功",Toast.LENGTH_SHORT).show();
				break;
			case MSG_CHECK_PAY_FAIL:// 从游戏服务器验证订单支付失败
				Toast.makeText(GoodsListActivity.this, "sample:支付失败",
						Toast.LENGTH_SHORT).show();
				break;
			case MSG_GET_ORDER_ID_SUCCESS://从游戏服务器获取订单号成功
				String orderid = (String)msg.obj;
				int changepoint = msg.arg1;
				int price  = msg.arg2;
				startPayEx(orderid,changepoint,price);
				break;
			default:
				break;
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mlpsustdata = this.getIntent().getStringExtra("lpsust");
		showView();
	}


	public void showView() {
        
		setContentView(R.layout.goods_list);
		
		//支付点 295
		final Button pAnci = (Button) findViewById(R.id.pay_anci);
		pAnci.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				new GetServerTask(mlpsustdata,295,1,0).execute();
				//startPay(295, 100);
			}
		});

		//支付点 298
		findViewById(R.id.pay_pilianggoumai).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						new GetServerTask(mlpsustdata,298,50,0).execute();
					}
				});
		//支付点 299
		findViewById(R.id.pay_baoci).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				new GetServerTask(mlpsustdata,299,1500,0).execute();
			}
		});
		//支付点 300
		findViewById(R.id.pay_baoshichang).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						//startPay(267, 3000);
						new GetServerTask(mlpsustdata,300,3000,0).execute();
					}
				});
		//支付点 301
		findViewById(R.id.pay_mianfei).setOnClickListener(
						new OnClickListener() {

							@Override
							public void onClick(View v) {
								new GetServerTask(mlpsustdata,301,10000,0).execute();
							}
						});
		
		
		//支付点 302
		findViewById(R.id.pay_erbai).setOnClickListener(
										new OnClickListener() {

											@Override
											public void onClick(View v) {
												new GetServerTask(mlpsustdata,302,20000,0).execute();
											}
										});
		
		//支付点 99081
		findViewById(R.id.pay_wubaiyi).setOnClickListener(
								new OnClickListener() {

									@Override
									public void onClick(View v) {
										new GetServerTask(mlpsustdata,99081,50100,0).execute();
									}
								});
		
		//支付点 99080
		findViewById(R.id.pay_liangqianyi).setOnClickListener(
										new OnClickListener() {

											@Override
											public void onClick(View v) {
												new GetServerTask(mlpsustdata,99080,200100,0).execute();
											}
										});
		
		
		//开放价格
		final EditText etPrice = (EditText) findViewById(R.id.et_price);
		final Button pkaifangjiage = (Button) findViewById(R.id.pay_kaifangjiage);
		pkaifangjiage.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				String price = etPrice.getText().toString().trim();
				if (TextUtils.isEmpty(price)) {
					Toast.makeText(GoodsListActivity.this, "价格不为空",Toast.LENGTH_SHORT).show();
					etPrice.requestFocus();
				} else if (Integer.parseInt(price) <= 0) {
					Toast.makeText(GoodsListActivity.this, "价格大于0",Toast.LENGTH_SHORT).show();
					etPrice.requestFocus();

				} else {
					//startPay(10, Integer.parseInt(price));
					new GetServerTask(mlpsustdata,539,Integer.parseInt(price),2).execute();
				}

			}
		});
		// 退出游戏应用示例
		alertDialogBuilder = new AlertDialog.Builder(this)
				.setMessage("是否确定退出？").setCancelable(true)
				.setPositiveButton("是", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						GoodsListActivity.this.finish();
					}
				})
				.setNegativeButton("否", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});

	}
	public static ProgressDialog showProgress(Context context,CharSequence title, CharSequence message)
	{
		ProgressDialog dialog = new ProgressDialog(context);
		dialog.setTitle(title);
		dialog.setMessage(message);
		dialog.setIndeterminate(false);
		dialog.setCancelable(false);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();
		return dialog;
	}
	/****游戏客户端从游戏服务端获取订单号****
	 * context:
	 * openappid：
	 * stdata：
	 * chargepoint：
	 */
	public static String getOrderInfo(Context context,String openappid,String stData,String chargepoint,String money) {
    	String rtv = "";
		HttpResponse response = null;
		String[] params = {
				"appid", openappid,
				"lpsust",stData,
				"waresid", chargepoint,
				"money", money,
		};
		
		String target = /*"create_order.xhtml";*/"createOrder";//"cp/getOrder";
		//hostUrl = "http://www.baidu.com/";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", CONTENTTYPE);
		try {
			response = HttpUtil.request(RequestMethod.GET, hostUrl, target, params, headers);
		} catch (HttpUtilException e) {
			e.printStackTrace();
			return rtv;
		}
		rtv =  HttpJsonParser.parserOrderInfo(response);
		return rtv;
    }
	/****游戏客户端从游戏服务端校验订单支付是否成功****
	 * context:
	 * orderid：
	 */
	public static boolean checkOrderInfo(Context context,String orderid) {
    	boolean rtv = false;
		HttpResponse response = null;
		String[] params = { "exorderno", orderid,
		};
		
		String target = /*"check_order.xhtml";*/"checkOrder";//"cp/checkOrder";
			
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", CONTENTTYPE);
		try {
			response = HttpUtil.request(RequestMethod.GET, hostUrl, target, params, headers);
		} catch (HttpUtilException e) {
			e.printStackTrace();
			return rtv;
		}
		rtv =  HttpJsonParser.parserCheckOrderInfo(response);
		return rtv;
    }
	/****游戏客户端本地生成订单号调用接口****
	 * context:
	 * orderid：
	 * waresid：
	 * price：
	 */
	public void startPay(int waresid, int price) {
		/***********
		 *  支付LenovoGameApi.doPay（） 接口 调用
		 */
		GamePayRequest payRequest = new GamePayRequest();
		// 请填写商品自己的参数
		payRequest.addParam("notifyurl", "");//当前版本暂时不用，传空String
		payRequest.addParam("appid", Config.appid);
		payRequest.addParam("waresid", waresid);
		payRequest.addParam("exorderno", "sample" + System.currentTimeMillis());
		payRequest.addParam("price", price);
		payRequest.addParam("cpprivateinfo", "123456");


		LenovoGameApi.doPay(GoodsListActivity.this,Config.appkey, payRequest, new IPayResult() {
			@Override
			public void onPayResult(int resultCode, String signValue,
					String resultInfo) {// resultInfo = 应用编号&商品编号&外部订单号
				
				if (LenovoGameApi.PAY_SUCCESS == resultCode) {
					//支付成功
					Toast.makeText(GoodsListActivity.this, "sample:支付成功",Toast.LENGTH_SHORT).show();
				} else if (LenovoGameApi.PAY_CANCEL == resultCode) {
					Toast.makeText(GoodsListActivity.this, "sample:取消支付",Toast.LENGTH_SHORT).show();
					// 取消支付处理，默认采用finish()，请根据需要修改
					Log.e(Config.TAG, "return cancel");
				} else {
					Toast.makeText(GoodsListActivity.this, "sample:支付失败",Toast.LENGTH_SHORT).show();
					// 计费失败处理，默认采用finish()，请根据需要修改
					Log.e(Config.TAG, "return Error");
				}

			}
		});
	}
	/****游戏客户端从游戏服务端获取订单后调用的接口****
	 * context:
	 * orderid：
	 * waresid：
	 * price：
	 */
	public void startPayEx(String orderid,int waresid, int price) {
		/***********
		 *  支付LenovoGameApi.doPay（） 接口 调用
		 */
		GamePayRequest payRequest = new GamePayRequest();
		// 请填写商品自己的参数
		payRequest.addParam("notifyurl", "");
		payRequest.addParam("appid", Config.appid);
		payRequest.addParam("waresid", waresid);//即chargepoint
		payRequest.addParam("exorderno", orderid);
		payRequest.addParam("price", price);
		payRequest.addParam("cpprivateinfo", "123456");

		LenovoGameApi.doPay(GoodsListActivity.this,Config.appkey, payRequest, new IPayResult() {
			@Override
			public void onPayResult(int resultCode, String signValue,
					String resultInfo) {// resultInfo = 应用编号&商品编号&外部订单号
				
				
				/*String resultInfo = AppId + "&" + ChargePoint + "&" + exOrderNo;
				String returnValue = exOrderNo + "&" + retCode;
				
				Log.i("test", "==finished==setResult=="+resultInfo+returnValue);
				Intent i = new Intent();
				i.putExtra("resultInfo", resultInfo);
				i.putExtra("signvalue", returnValue);
				((PayManagerActivity)mActivity).onResult(0,retCode, i);*/
				
				
				
				Log.e("test", "demo onPayResult resultCode="+resultCode+"=resultInfo="+resultInfo);
				
				if (LenovoGameApi.PAY_SUCCESS == resultCode) {
					 String[] strResult = resultInfo.split("&");
					 new GetServerTask(strResult[2],1).execute();//strResult[2] 订单号
				} else if (LenovoGameApi.PAY_CANCEL == resultCode) {
					Toast.makeText(GoodsListActivity.this, "sample:取消支付",Toast.LENGTH_SHORT).show();
					// 取消支付处理，默认采用finish()，请根据需要修改
					Log.e(Config.TAG, "return cancel");
				} else {
					 String[] strResult = resultInfo.split("&");
					 new GetServerTask(strResult[2],1).execute();//strResult[2] 订单号
					// 计费失败处理，默认采用finish()，请根据需要修改
					Log.e(Config.TAG, "return Error");
				}

			}
		});
	}

	/**
	 * 返回键
	 */
	@Override
	public void onBackPressed() {
		LenovoGameApi.doQuit(GoodsListActivity.this,  new IAuthResult() {
			
			@Override
			public void onFinished(boolean ret, String data) {
				// TODO Auto-generated method stub
				Log.i("demo", "onFinished："+data);
				if(ret){
					GoodsListActivity.this.finish();
					System.exit(0);
				}else{
					//"用户点击底部返回键或点击弹窗close键"
				}
				
				/*Log.i("demo", "onFinished："+data);
				if(result == 0){//"用户点击弹窗close键"
					GoodsListActivity.this.finish();
					System.exit(0);
				}else if(result == -1){//"用户点击底部返回键"
				}else if(result == -2){//"用户点击弹窗open键"
					GoodsListActivity.this.finish();
					System.exit(0);
				}*/
			}

		});
	}
	private class GetServerTask extends AsyncTask<String, Boolean, Boolean> {
	    private int mChargePoint;
	    private int mPrice;
	    private int mtype;//0 从服务器获取订单  1从服务器验证支付是否成功 // 2 从服务器获取订单开放价格
	    private String lpsust;
	    private String orderid;
	    private ProgressDialog dialog ;
	    GetServerTask(String st,int changepoint,int price,int type){
	    	lpsust = st;
	    	mChargePoint = changepoint;
	    	mPrice = price;
	    	mtype = type;
	    }
	    
	    GetServerTask(String ordernum,int type){
	    	orderid = ordernum;
	    	mtype = type;
	    }
	    @Override
	    protected void onPreExecute() {
	    	dialog = new ProgressDialog(GoodsListActivity.this);
			dialog.setTitle("");
			if(mtype == 0 || mtype == 2) {
				dialog.setMessage("正在生成订单");
			} else {
				dialog.setMessage("正在游戏服务器验证支付是否成功");
			}
			dialog.setIndeterminate(false);
			dialog.setCancelable(false);
			dialog.setCanceledOnTouchOutside(false);
			
			try {
				if(GoodsListActivity.this != null && !GoodsListActivity.this.isFinishing()) {
					dialog.show();
				}
			} catch(Exception e){}
	    }

	    @Override
	    protected Boolean doInBackground(String... params) {
	    	
            if(mtype == 0 || mtype == 2) {
            	String strWaresid = mtype==0?String.valueOf(mChargePoint):"0";
            	orderid = getOrderInfo(GoodsListActivity.this,Config.appid,lpsust,strWaresid,String.valueOf(mPrice));
            	if(!TextUtils.isEmpty(orderid)) {
            		return true;
            	}
            } else if(mtype == 1) {
            	int i = 0;
            	while(i++ < MAX_REQUEST_COUNT)
            	{
                	boolean rtv =  checkOrderInfo(GoodsListActivity.this,orderid);
                	if(rtv) {
                		return true;
                	}
                	try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
            	}

            }
	      return false;
	    }

	    @Override
	    protected void onPostExecute(Boolean result) {
	    	dialog.dismiss();
	    	if(mtype == 0 || mtype == 2) {
	    		
		    	if(result) {
		    		//订单生成成功
		    		final Message msg = new Message();
					msg.what = MSG_GET_ORDER_ID_SUCCESS;
					msg.obj = orderid;
					msg.arg1 = mChargePoint;
					msg.arg2 = mPrice;
					myHandlerEx.sendMessage(msg);
		    	}  else {
		    		//订单生成失败
	    			Log.i(Config.TAG, "error ");
	    			Toast.makeText(GoodsListActivity.this, "cp 订单生成失败",Toast.LENGTH_SHORT).show();
		    	}
	    	}  else if(mtype == 1) {
	    		
	    		if(result) {
	    			//订单校验成功
		    		final Message msg = new Message();
					msg.what = MSG_CHECK_PAY_SUCCESS;
					myHandlerEx.sendMessage(msg);
		    	}  else {
		    		//订单校验失败
		    		final Message msg = new Message();
		    		msg.what = MSG_CHECK_PAY_FAIL;
		    		myHandlerEx.sendMessage(msg);
		    		Log.i(Config.TAG, "error ");
		    	}
	    	}
	    }
	  }
}
